---
layout: page
title: "TODO"
permalink: /todo/
---

_This is a placeholder page to write **TODO** your own story._

_This page can be anything of your choice._

## Tips

- Use [github project][1] to list todos and track their progress.
- Use [trello][2] to write todos and manage them.
- Use [microsoft todo][3] app to write and manage your ideas.
- Use this page as a todo or a notes collection.

<!-- links in the post -->
[1]: https://github.com/features/project-management/
[2]: https://trello.com/home
[3]: https://todo.microsoft.com/en-gb
